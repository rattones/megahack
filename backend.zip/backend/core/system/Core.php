<?php 
namespace core\system;

class Configuration 
{

}